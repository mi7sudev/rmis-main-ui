import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, err, handleApi } from "@/lib/api";
import { requireApplicantFromReq, getApplicantIdForUser } from "@/lib/auth";
import { uploadDir } from "@/lib/env";
import { auditLog } from "@/lib/audit-log";
import { getClientIp } from "@/lib/rate-limit";
import fs from "fs/promises";
import path from "path";
import crypto from "crypto";
import {
  ALLOWED_UPLOAD_MIMES,
  ALLOWED_UPLOAD_EXTS,
  MIME_TO_EXT,
  isValidDocumentCategory,
  type ValidDocumentCategory,
} from "@/lib/file-types";
import {
  listApplicantDocuments,
  writeMeta,
  type DocumentMeta,
} from "@/lib/documents";

const UPLOAD_ROOT = uploadDir();
const MAX_SIZE = 10 * 1024 * 1024; // 10MB

// ============================================================================
// Production `files` table integration.
//
// Uploaded files are stored in `files` with a polymorphic link in
// `files_related_mph` (FileRelatedLink). We mirror that legacy convention so
// new uploads are consistent with the existing ~60 production rows and join
// cleanly with any code that reads those tables.
//
// `created_at` / `updated_at` / `published_at` are written as INTEGER
// ms-epoch values (via raw SQL) to match the existing production convention —
// Prisma's typed client would store ISO TEXT, creating a mixed-type column.
//
// All writes to `files` / `files_related_mph` are wrapped in try/catch: if the
// DB write fails for any reason (constraint, schema drift, etc.) we must NOT
// fail the upload — the binary is already on disk and the sidecar JSON is the
// source of truth for the upload feature.
//
// `field` value in `files_related_mph` follows the existing production
// convention for `related_type = "api::applicant.applicant"` (e.g.
// "education_attachment", "profile_picture", "merged_pdf").
// ============================================================================
const FILE_RELATED_TYPE_APPLICANT = "api::applicant.applicant";

const CATEGORY_TO_FILE_FIELD: Record<ValidDocumentCategory, string> = {
  PDS: "merged_pdf",
  RESUME: "merged_pdf",
  EDUCATION: "education_attachment",
  WORK_EXPERIENCE: "work_experience_attachment",
  TRAINING: "training_attachment",
  ELIGIBILITY: "eligibility_attachment",
  AWARD: "award_attachment",
  ACCOMPLISHMENT: "award_attachment",
  COE: "merged_pdf",
  PERFORMANCE_EVALUATION: "merged_pdf",
  SUPPORTING: "merged_pdf",
  PROFILE_PICTURE: "profile_picture",
};

// ============================================================================
// Sidecar JSON layout.
//
// The production DB has NO dedicated `documents` table for the
// document-intelligence feature — uploaded files are stored in the `files`
// table with a polymorphic relation in `files_related_mph`. We DO write to
// `files` + `files_related_mph` (see helpers below) so the upload stays
// compatible with the existing production data, but the local
// document-intelligence feature also needs richer metadata (extraction
// status, category, extracted JSON) that doesn't fit the `files` schema. That
// extra metadata is persisted as a sidecar JSON file in the upload directory
// (one metadata file per uploaded document).
//
// Directory layout:
//   upload/<applicantId>/<uuid>.<ext>          ← the binary file
//   upload/<applicantId>/<uuid>.meta.json      ← metadata sidecar
//
// The shared read/write/list helpers live in `@/lib/documents` so both this
// applicant-facing upload route and the admin/evaluator-facing
// `/api/admin/applicants/[id]` route use one implementation.
// ============================================================================

export const GET = handleApi(async (req: NextRequest) => {
  const user = await requireApplicantFromReq(req);
  const applicantId = await getApplicantIdForUser(parseInt(user.id, 10));
  if (!applicantId) return err("Applicant profile not found", 404);
  const docs = await listApplicantDocuments(applicantId);
  return ok(docs);
});

export const POST = handleApi(async (req: NextRequest) => {
  const user = await requireApplicantFromReq(req);
  const applicantId = await getApplicantIdForUser(parseInt(user.id, 10));
  if (!applicantId) return err("Applicant profile not found", 404);

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  const rawCategory = (formData.get("category") as string) || "SUPPORTING";

  if (!isValidDocumentCategory(rawCategory)) {
    return err(`Invalid document category: ${rawCategory}`, 400);
  }
  const category = rawCategory;

  if (!file) return err("No file provided", 400);
  if (file.size > MAX_SIZE) return err("File too large (max 10MB)", 413);

  const ext = path.extname(file.name).toLowerCase();
  const isKnownMime = (ALLOWED_UPLOAD_MIMES as readonly string[]).includes(file.type);
  const isGenericMime = file.type === "application/octet-stream" || file.type === "";
  const isKnownExt = (ALLOWED_UPLOAD_EXTS as readonly string[]).includes(ext);

  if (!isKnownMime) {
    if (!isGenericMime) {
      return err(
        `Unsupported file type: ${file.type}. Supported: images (PNG/JPEG/GIF/WebP), PDF, Word (.doc/.docx), Excel (.xlsx/.xls)`,
        415
      );
    }
    if (!isKnownExt) {
      return err(
        `Unsupported file: ${file.name}. Allowed extensions: ${ALLOWED_UPLOAD_EXTS.join(", ")}`,
        415
      );
    }
  }

  let mimeType = file.type;
  if ((!mimeType || isGenericMime) && isKnownExt) {
    mimeType =
      ext === ".xlsx"
        ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        : ext === ".xls"
        ? "application/vnd.ms-excel"
        : ext === ".docx"
        ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        : ext === ".doc"
        ? "application/msword"
        : ext === ".pdf"
        ? "application/pdf"
        : ext === ".png"
        ? "image/png"
        : ext === ".jpg" || ext === ".jpeg"
        ? "image/jpeg"
        : ext === ".gif"
        ? "image/gif"
        : ext === ".webp"
        ? "image/webp"
        : "application/octet-stream";
  }
  const safeExt = ext || MIME_TO_EXT[mimeType] || ".bin";

  // SECURITY: Sanitize extension — strip any path traversal characters
  // (path.extname should already be safe, but defense in depth)
  const sanitizedExt = path.basename(safeExt);

  // Per-applicant directory + uuid-based filename
  const applicantDir = path.join(UPLOAD_ROOT, String(applicantId));
  await fs.mkdir(applicantDir, { recursive: true });
  const id = crypto.randomUUID();
  const safeName = `${id}${sanitizedExt}`;
  const filePath = path.join(applicantDir, safeName);
  const relPath = `upload/${applicantId}/${safeName}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(filePath, buffer);

  const now = new Date().toISOString();
  const meta: DocumentMeta = {
    id,
    applicantId,
    uploadedById: parseInt(user.id, 10),
    fileName: safeName,
    originalName: file.name,
    mimeType,
    size: file.size,
    filePath: relPath,
    category,
    status: "UPLOADED",
    extractedJson: null,
    extractionError: null,
    extractedAt: null,
    createdAt: now,
    updatedAt: now,
    fileTableId: null,
  };

  // ------------------------------------------------------------------------
  // Write to the production `files` + `files_related_mph` tables so the
  // upload is visible to any code that reads those tables.
  // Non-fatal: if either insert throws, we log and continue — the binary is
  // already on disk and the sidecar JSON remains the source of truth.
  // ------------------------------------------------------------------------
  try {
    const fileTableId = await insertFileRow({
      originalName: file.name,
      ext: sanitizedExt,
      mime: mimeType,
      sizeBytes: file.size,
    });
    if (fileTableId !== null) {
      await linkFileToApplicant(fileTableId, applicantId, category);
    }
    meta.fileTableId = fileTableId;
  } catch (fileDbErr) {
    console.error(
      "[documents/upload] Non-fatal: failed to write to files / files_related_mph:",
      fileDbErr
    );
  }

  await writeMeta(path.join(applicantDir, `${id}.meta.json`), meta);

  // Audit: applicant uploaded a document
  await auditLog({
    userId: user.id,
    userLabel: user.name ? `${user.name} (${user.email})` : user.email,
    userRole: user.role,
    action: "DOCUMENT_UPLOADED",
    entityType: "document",
    entityId: id,
    description: `Uploaded ${category} document: ${file.name}`,
    ipAddress: getClientIp(req),
  });

  return ok(meta, 201);
});

// ----------------------------------------------------------------------------
// Helpers — production `files` / `files_related_mph` table writes.
// ----------------------------------------------------------------------------

/**
 * Insert a row into the production `files` table mirroring the legacy
 * convention (ms-epoch INTEGER timestamps, KB `size`, `/uploads/<hash><ext>`
 * URL, `provider="local"`, `folder_path="/"`). Returns the new file.id or null
 * if the insert did not produce a row.
 */
async function insertFileRow(args: {
  originalName: string;
  ext: string;
  mime: string;
  sizeBytes: number;
}): Promise<number | null> {
  const now = Date.now(); // ms-epoch INTEGER — matches production convention
  const documentId = crypto.randomUUID();
  // File hashes use the legacy `<sanitized_name>_<random_hex>` format —
  // namespacing avoids
  // collisions in /uploads/ which is shared across all applicants.
  const baseName =
    args.originalName.replace(/\.[^.]+$/, "").replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40) ||
    "file";
  const hash = `${baseName}_${crypto.randomBytes(5).toString("hex")}`;
  // `files.size` stores KB (float), not bytes.
  const sizeKb = Math.round((args.sizeBytes / 1024) * 100) / 100;
  const fileUrl = `/uploads/${hash}${args.ext}`;

  const inserted = await db.$queryRaw<{ id: number }[]>`
    INSERT INTO files (
      document_id, name, ext, mime, folder_path, provider,
      hash, size, url, preview_url,
      width, height,
      created_at, updated_at, published_at,
      created_by_id, updated_by_id, locale
    ) VALUES (
      ${documentId}, ${args.originalName}, ${args.ext}, ${args.mime}, ${"/"}, ${"local"},
      ${hash}, ${sizeKb}, ${fileUrl}, ${null},
      ${null}, ${null},
      ${now}, ${now}, ${now},
      ${null}, ${null}, ${null}
    )
    RETURNING id
  `;
  return inserted[0]?.id ?? null;
}

/**
 * Link a `files` row to an applicant via the `files_related_mph` polymorphic
 * table, mirroring the legacy convention (`related_type =
 * "api::applicant.applicant"`, `field` derived from the upload category).
 */
async function linkFileToApplicant(
  fileId: number,
  applicantId: number,
  category: ValidDocumentCategory
): Promise<void> {
  const relatedField = CATEGORY_TO_FILE_FIELD[category] ?? "merged_pdf";
  // `order` is a SQL reserved word — quote it as an identifier.
  await db.$executeRaw`
    INSERT INTO files_related_mph (
      file_id, related_id, related_type, field, "order"
    ) VALUES (
      ${fileId}, ${applicantId}, ${FILE_RELATED_TYPE_APPLICANT}, ${relatedField}, ${1}
    )
  `;
}
