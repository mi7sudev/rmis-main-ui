import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, err, handleApi } from "@/lib/api";
import { requireApplicantFromReq, getApplicantIdForUser } from "@/lib/auth";
import { findApplicantEligibilityId } from "@/lib/applicant-data";

export const DELETE = handleApi(async (
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) => {
  const user = await requireApplicantFromReq(req);
  const applicantId = await getApplicantIdForUser(parseInt(user.id, 10));
  if (!applicantId) return err("Applicant profile not found", 404);
  const { id: idStr } = await params;
  const id = parseInt(idStr, 10);
  if (isNaN(id)) return err("Invalid id", 400);

  const eligId = await findApplicantEligibilityId(id, applicantId);
  if (!eligId) return err("Not found", 404);

  // Delete junction links (applicant + category) then the child record.
  await db.applicantEligibilityLink.deleteMany({
    where: { applicantEligibilityId: eligId, applicantId },
  });
  await db.applicantEligibilityCategoryLink.deleteMany({
    where: { applicantEligibilityId: eligId },
  });
  await db.applicantEligibility.delete({ where: { id: eligId } });
  return ok({ deleted: true });
});
