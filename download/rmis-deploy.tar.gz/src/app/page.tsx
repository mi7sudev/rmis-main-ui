"use client";

import { SessionProvider, useSession } from "@/components/session-provider";
import { NavProvider, useNav, homeForRole } from "@/components/nav-provider";
import { AppShell } from "@/components/shell/app-shell";
import { Suspense, useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { ViewTransition } from "@/components/ui/motion/view-transition";

// Public views
import { PublicLanding } from "@/components/workspaces/public/public-landing";
import { JobsView } from "@/components/views/jobs-view";
import { SignInView } from "@/components/views/signin-view";
import { SignUpView } from "@/components/views/signup-view";

// Applicant (new workspaces)
import { ApplicantHome } from "@/components/workspaces/applicant/applicant-home";
import { ProfileView } from "@/components/views/profile-view";

// Evaluator (new workspace)
import { ReviewQueue } from "@/components/workspaces/evaluator/review-queue";
import { ReviewWorkspace } from "@/components/workspaces/evaluator/review-workspace";

// Admin (new workspaces)
import { CommandCenter } from "@/components/workspaces/admin/command-center";
import { RecruitmentList } from "@/components/workspaces/recruitment/recruitment-list";
import { JobWorkspace } from "@/components/workspaces/recruitment/job-workspace";
import { CandidateWorkspace } from "@/components/workspaces/candidates/candidate-workspace";
import { CandidateDetail } from "@/components/workspaces/candidates/candidate-detail";
import { AnalyticsWorkspace } from "@/components/workspaces/analytics/analytics";
import { SettingsWorkspace } from "@/components/workspaces/settings/settings";

function LoadingShell() {
  return (
    <div className="flex-1 items-center justify-center p-12">
      <div className="mx-auto w-full max-w-3xl space-y-4">
        <Skeleton className="h-8 w-1/3" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    </div>
  );
}

function Router() {
  const { view, params, navigate } = useNav();
  const { user, loading } = useSession();

  // Redirect auth views if already logged in. The role→home table and the
  // hash write both live behind the Nav seam (nav-provider registry).
  useEffect(() => {
    if (loading) return;
    if ((view === "signin" || view === "signup") && user) {
      navigate(homeForRole(String(user.role)));
    }
  }, [view, user, loading, navigate]);

  // The view key drives the ViewTransition wipe. Include params.job so
  // navigating between job details also transitions.
  const viewKey = `${view}:${params.job ?? params.id ?? ""}`;

  function renderView() {
    // `view` is always canonical here — legacy names (admin-jobs,
    // evaluator-queue, applicant-details, …) are resolved by the VIEW_ALIASES
    // registry in nav-provider before they reach the Router.

    // Not logged in — public landing by default, jobs board on explicit view
    if (!loading && !user) {
      if (view === "signup") return <SignUpView />;
      if (view === "signin") return <SignInView />;
      if (view === "jobs") return <JobsView />;
      return <PublicLanding />;
    }

    if (loading) return <LoadingShell />;

    // Applicant role
    if (String(user?.role) === "APPLICANT") {
      if (view === "profile") return <ProfileView />;
      if (view === "jobs") return <JobsView />;
      return <ApplicantHome />;
    }

    // Evaluator role
    if (String(user?.role) === "EVALUATOR") {
      if (view === "evaluator-review") return <ReviewWorkspace />;
      if (view === "candidate") return <CandidateDetail />;
      if (view === "candidates") return <CandidateWorkspace />;
      if (view === "recruitment") return <RecruitmentList />;
      if (view === "job") return <JobWorkspace />;
      if (view === "jobs") return <JobsView />;
      return <ReviewQueue />;
    }

    // Administrator role
    if (String(user?.role) === "ADMIN") {
      if (view === "recruitment") return <RecruitmentList />;
      if (view === "job") return <JobWorkspace />;
      if (view === "candidates") return <CandidateWorkspace />;
      if (view === "candidate") return <CandidateDetail />;
      if (view === "review-queue") return <ReviewQueue />;
      if (view === "evaluator-review") return <ReviewWorkspace />;
      if (view === "analytics") return <AnalyticsWorkspace />;
      if (view === "settings") return <SettingsWorkspace initial={view} />;
      if (view === "jobs") return <JobsView />;
      return <CommandCenter />;
    }

    return <JobsView />;
  }

  // Wrap in ViewTransition so every view change plays the cohesive wipe.
  return (
    <ViewTransition viewKey={viewKey}>
      {renderView()}
    </ViewTransition>
  );
}

function Shell() {
  return (
    <AppShell>
      <Suspense fallback={<LoadingShell />}>
        <Router />
      </Suspense>
    </AppShell>
  );
}

export default function Page() {
  return (
    <SessionProvider>
      <NavProvider>
        <Shell />
      </NavProvider>
    </SessionProvider>
  );
}
