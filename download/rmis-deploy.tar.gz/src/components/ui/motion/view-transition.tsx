"use client";

// ============================================================================
// ViewTransition — clip-path wipe between route/view changes.
//
// This is the #1 award-winning feature: smooth page-to-page navigation.
// When the hash-based view changes, a navy panel wipes across the viewport
// (left → right), the new content renders underneath, then the panel wipes
// away (left → right) to reveal it. One consistent transition for EVERY
// navigation — cohesion is what makes it feel premium.
//
// - Uses a single fixed overlay div with clip-path animation (no React tree
//   manipulation, no layout thrash).
// - Honors reduced-motion: skips the wipe entirely, content swaps instantly.
// - Mounted once at the app root so it covers ALL view changes (landing →
//   signin → jobs → dashboard, etc.).
// ============================================================================

import * as React from "react";
import { motion, AnimatePresence } from "motion/react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

type ViewTransitionProps = {
  /** the current view key — when this changes, the wipe plays */
  viewKey: string | number;
  children: React.ReactNode;
};

type Phase = "idle" | "covering" | "revealing";

export function ViewTransition({ viewKey, children }: ViewTransitionProps) {
  const reduced = useReducedMotion();
  const [phase, setPhase] = React.useState<Phase>("idle");
  const [displayChildren, setDisplayChildren] = React.useState(children);
  const prevKeyRef = React.useRef(viewKey);
  // Always-current children for the mid-wipe swap (avoids a stale closure
  // swapping in old content when children update during the wipe).
  const childrenRef = React.useRef(children);

  // Runs after EVERY commit: keep childrenRef current, and — when the view
  // key has NOT changed — sync the latest children into displayChildren.
  // The wipe effect below only re-runs when viewKey changes, but children
  // ALSO change while the key stays constant (session loading → content on a
  // direct #/jobs load, data refreshes, Fast Refresh). Without this sync the
  // page would stay frozen on the previous children (e.g. LoadingShell)
  // forever, because nothing told ViewTransition to swap them.
  React.useEffect(() => {
    childrenRef.current = children;
    if (!reduced && viewKey === prevKeyRef.current) {
      setDisplayChildren(children);
    }
  });

  React.useEffect(() => {
    // No transition on the very first render or when reduced-motion is on.
    if (reduced || viewKey === prevKeyRef.current) {
      setDisplayChildren(children);
      prevKeyRef.current = viewKey;
      return;
    }

    // View changed → play the wipe.
    // Phase 1: navy panel wipes ACROSS (covers the viewport, left→right).
    setPhase("covering");

    // Mid-wipe: swap the children under the cover so the new view is rendered
    // by the time the panel starts revealing (childrenRef = latest version).
    const swapT = window.setTimeout(() => {
      setDisplayChildren(childrenRef.current);
      prevKeyRef.current = viewKey;
    }, 280);

    // Phase 2: panel wipes AWAY (reveals the new view, left→right).
    const revealT = window.setTimeout(() => {
      setPhase("revealing");
    }, 340);

    // Phase 3: done — unmount the overlay until next navigation.
    const doneT = window.setTimeout(() => {
      setPhase("idle");
    }, 820);

    return () => {
      window.clearTimeout(swapT);
      window.clearTimeout(revealT);
      window.clearTimeout(doneT);
    };
  }, [viewKey, reduced]);

  return (
    <>
      {/* The actual page content (swapped mid-wipe) */}
      {displayChildren}

      {/* Wipe overlay — navy panel that covers then reveals.
          Two layers: the panel itself + a thin gold leading edge. */}
      <AnimatePresence>
        {phase !== "idle" && !reduced && (
          <motion.div
            key="wipe"
            className="fixed inset-0 z-[90] pointer-events-none"
            initial={{ clipPath: "inset(0% 0% 0% 100%)" }}
            animate={
              phase === "covering"
                ? { clipPath: "inset(0% 0% 0% 0%)" }   // wipe IN: right edge → left
                : { clipPath: "inset(0% 0% 0% 100%)" }  // wipe OUT: left → right edge
            }
            exit={{ clipPath: "inset(0% 0% 0% 100%)" }}
            transition={{
              duration: phase === "covering" ? 0.34 : 0.5,
              ease: [0.76, 0, 0.24, 1], // expo-in-out — crisp, premium
            }}
            style={{
              backgroundColor: "#112E81",
              // A thin gold leading edge on the right side of the panel
              boxShadow: "inset -2px 0 0 0 #E8A317",
            }}
          >
            {/* Centered brand mark during the wipe — premium detail */}
            <motion.div
              className="flex h-full w-full items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: phase === "covering" ? 1 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center gap-3">
                <img src="/MIRDC.png" alt="" className="h-10 w-auto object-contain" />
                <img src="/RMIS.png" alt="" className="h-10 w-auto object-contain" />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
