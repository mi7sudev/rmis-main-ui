"use client";

// =============================================================================
// RMIS — Applicant Profile View (Accenture language)
// Mode-aware canvas (light :root / dark .dark token sheets) · electric blue
// #1591DC · royal-gold kickers only.
// WorkspaceTitle header + flat sharp cards, square avatar block, section nav
// rail with solid primary active block. 7-section profile wizard with AI
// document intelligence.
// =============================================================================

import { useRef } from "react";
import { useSession } from "@/components/session-provider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog";
import { formatDate, fullName } from "@/lib/client";
import {
  CheckCircle2,
  AlertCircle,
  Loader2,
  ShieldCheck,
  Info,
  CircleDot,
  User,
} from "lucide-react";
import { Reveal } from "@/components/ui/motion/reveal";

import { SECTIONS } from "./profile/types";
import { useProfileData } from "./profile/use-profile-data";
import { PersonalInfoSection } from "./profile/personal-info-section";
import { EducationSection } from "./profile/education-section";
import { WorkExperienceSection } from "./profile/work-experience-section";
import { TrainingSection } from "./profile/training-section";
import { EligibilitySection } from "./profile/eligibility-section";
import { AwardsSection } from "./profile/awards-section";
import { DocumentsSection } from "./profile/documents-section";
import { UploadPdsCard } from "./upload-pds-card";
import { Eyebrow, WorkspaceTitle, Skeleton, ErrorState } from "@/components/primitives/workspace";

export function ProfileView() {
  const { user } = useSession();
  const data = useProfileData();
  const sectionsRef = useRef<HTMLDivElement>(null);
  const {
    loading, error, profile, loadAll, activeSection, setActiveSection,
    reference, personalForm, personalDirty,
    savingPersonal, updatePersonalField, savePersonal,
    educations, workExperiences, trainings, eligibilities, awards,
    educationHandlers, workHandlers, trainingHandlers, eligibilityHandlers,
    awardsHandlers, documentsHandlers, documents,
    completeOpen, setCompleteOpen, markingComplete, handleMarkComplete,
    completion, canMarkComplete,
  } = data;

  void user;

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <div className="relative z-10 mx-auto max-w-[1400px] 2xl:max-w-[1680px] px-4 py-8 sm:px-6 lg:px-8">
          <div className="border-b border-border pb-8">
            <Eyebrow>Profile</Eyebrow>
            <div className="mt-3">
              <WorkspaceTitle title="My Profile" />
            </div>
          </div>
          <Reveal y={12} delay={0.1}>
            <Skeleton className="mt-6 h-24 w-full" />
            <Skeleton className="mt-3 h-16 w-full" />
            <div className="mt-6 grid gap-4 lg:grid-cols-[260px_1fr]">
              <Skeleton className="h-72" />
              <Skeleton className="h-96" />
            </div>
          </Reveal>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <div className="relative z-10 mx-auto max-w-[1400px] 2xl:max-w-[1680px] px-4 py-8 sm:px-6 lg:px-8">
          <div className="border-b border-border pb-8">
            <Eyebrow>Profile</Eyebrow>
            <div className="mt-3">
              <WorkspaceTitle title="My Profile" />
            </div>
          </div>
          <Reveal y={20}>
            <div className="mt-8 border border-border bg-card">
              <ErrorState message={error || "Profile not found"} onRetry={loadAll} />
            </div>
          </Reveal>
        </div>
      </div>
    );
  }

  const applicantName = fullName({
    firstName: profile.firstName,
    middleName: profile.middleName,
    lastName: profile.lastName,
    extensionName: profile.extensionName,
  });

  // Initials for the square avatar block ("Maria C. Santos" → "MS").
  const initials = (applicantName || "?")
    .split(/\s+/)
    .filter((w) => w && w !== "Jr." && w !== "Sr." && w !== "III")
    .map((w) => w.charAt(0))
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="relative z-10 mx-auto max-w-[1400px] 2xl:max-w-[1680px] px-4 py-8 sm:px-6 lg:px-8">
        {/* Header — kicker → display title */}
        <header className="border-b border-border pb-8">
          <Eyebrow>Profile</Eyebrow>
          <div className="mt-3">
            <WorkspaceTitle
              title="My Profile"
              description="Document-assisted application system — upload, extract, review, save."
            />
          </div>
        </header>

        {/* Identity + completion — single compact surface (section fill state
            lives in the nav rail below; no duplicate tile strip) */}
        <Reveal y={20}>
          <div className="mt-6 overflow-hidden rounded-none border border-border bg-card">
            <div className="px-5 py-4 sm:px-6 sm:py-5">
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="flex min-w-0 items-center gap-3.5">
                  <div className="grid size-11 shrink-0 place-items-center rounded-none bg-primary/10 text-sm font-extrabold text-primary" aria-hidden>
                    {initials || <User className="size-5" strokeWidth={1.5} />}
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="truncate text-base font-bold tracking-[-0.01em] text-foreground sm:text-lg">{applicantName}</h2>
                      {profile.isProfileComplete ? (
                        <Badge variant="success"><CheckCircle2 className="size-3" /> Complete</Badge>
                      ) : (
                        <Badge variant="destructive"><AlertCircle className="size-3" /> Incomplete</Badge>
                      )}
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {completion.filled} of {completion.total} sections have data
                      {profile.submittedDate ? ` · Submitted ${formatDate(profile.submittedDate)}` : ""}
                    </p>
                  </div>
                </div>
                {!profile.isProfileComplete && (
                  <Button
                    onClick={() => setCompleteOpen(true)}
                    disabled={!canMarkComplete}
                    className="shrink-0"
                  >
                    <ShieldCheck className="size-4" strokeWidth={1.5} /> Mark Complete
                  </Button>
                )}
              </div>
              <div className="mt-4 flex items-center gap-3">
                <span className="kicker hidden shrink-0 text-muted-foreground sm:inline">Completion</span>
                <Progress
                  value={completion.percent}
                  className="h-1.5 flex-1"
                />
                <span className="text-sm font-extrabold tabular-nums text-foreground">
                  {completion.percent}%
                </span>
              </div>
            </div>

            {/* Requirements hint */}
            {!canMarkComplete && !profile.isProfileComplete && (
              <div className="flex items-start gap-2.5 border-t border-border bg-destructive/10 px-5 py-2.5 sm:px-6">
                <Info className="mt-0.5 size-3.5 shrink-0 text-danger-ink" strokeWidth={1.5} />
                <span className="text-xs leading-relaxed text-danger-ink">
                  To mark your profile complete, you need at least: Personal Information (first name, last name, email), one Education entry, and one Work Experience entry.
                </span>
              </div>
            )}
          </div>
        </Reveal>

        {/* PDS auto-extraction — compact one-row upload strip */}
        <Reveal y={20}>
          <div className="mt-3">
            <UploadPdsCard
              onApplied={() => loadAll(true)}
              onReview={() => {
                setActiveSection("personal");
                requestAnimationFrame(() => {
                  sectionsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
                });
              }}
            />
          </div>
        </Reveal>

        {/* Two-column layout: left nav rail + right content cards.
            On desktop: the nav card is sticky with its own scroll container so
            it stays in view while the right content scrolls.
            On mobile: single column, nav sits above the content. */}
        <Reveal y={20}>
          <div ref={sectionsRef} className="mt-6 grid scroll-mt-4 gap-6 lg:grid-cols-[352px_1fr]">
            {/* LEFT NAV — flat sharp rail card, sticky on desktop */}
            <nav className="h-fit rounded-none border border-border bg-card p-2 lg:sticky lg:top-16 lg:max-h-[calc(100dvh-80px)] lg:overflow-y-auto">
              <p className="kicker px-3 pb-1.5 pt-2.5 text-base! text-muted-foreground">Sections</p>
              <div className="flex flex-col gap-1">
                {SECTIONS.map((s, i) => {
                  const isActive = activeSection === s.id;
                  const filled = completion.checks[s.id];
                  const Icon = s.icon;
                  return (
                    <button
                      key={s.id}
                      onClick={() => setActiveSection(s.id)}
                      aria-current={isActive ? "page" : undefined}
                      className={`flex w-full items-center gap-3 rounded-none px-3 py-3 text-left text-lg font-semibold transition-colors ${
                        isActive
                          ? "bg-primary text-primary-foreground"
                          : "text-foreground hover:bg-secondary"
                      }`}
                    >
                      <span className={`shrink-0 text-base font-extrabold tabular-nums ${isActive ? "text-white/70" : "text-muted-foreground"}`}>
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <Icon className="size-[22px] shrink-0" strokeWidth={1.5} />
                      <span className="min-w-0 flex-1 truncate">{s.label}</span>
                      {filled ? (
                        <CheckCircle2 className={`size-4.5 shrink-0 ${isActive ? "text-white" : "text-success"}`} strokeWidth={2} />
                      ) : (
                        <CircleDot className={`size-4.5 shrink-0 ${isActive ? "text-white/40" : "text-muted-foreground/40"}`} strokeWidth={1.5} />
                      )}
                    </button>
                  );
                })}
              </div>
            </nav>

            {/* RIGHT CONTENT — flat section cards scroll naturally */}
            <div className="min-w-0">
              {activeSection === "personal" && (
                <PersonalInfoSection
                  form={personalForm}
                  dirty={personalDirty}
                  saving={savingPersonal}
                  onChange={updatePersonalField}
                  onSave={savePersonal}
                />
              )}
              {activeSection === "education" && (
                <EducationSection items={educations} {...educationHandlers} />
              )}
              {activeSection === "work" && (
                <WorkExperienceSection items={workExperiences} {...workHandlers} />
              )}
              {activeSection === "training" && (
                <TrainingSection items={trainings} {...trainingHandlers} />
              )}
              {activeSection === "eligibility" && (
                <EligibilitySection items={eligibilities} reference={reference} {...eligibilityHandlers} />
              )}
              {activeSection === "awards" && (
                <AwardsSection items={awards} {...awardsHandlers} />
              )}
              {activeSection === "documents" && (
                <DocumentsSection documents={documents} {...documentsHandlers} />
              )}
            </div>
          </div>
        </Reveal>

        {/* Mark Profile Complete Confirmation */}
        <AlertDialog open={completeOpen} onOpenChange={setCompleteOpen}>
          <AlertDialogContent>
            <AlertDialogHeader className="shrink-0">
              <AlertDialogTitle className="text-lg font-bold tracking-[-0.01em] text-foreground">
                Mark Profile as Complete?
              </AlertDialogTitle>
              <AlertDialogDescription className="leading-relaxed">
                This will finalize your profile and allow you to apply for job
                postings. You can still edit your profile afterward, but the
                system will treat it as &quot;ready for application.&quot;
                <br /><br />
                Please ensure all information is accurate. Submitted profiles are
                subject to verification by the HR office.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="shrink-0">
              <AlertDialogCancel disabled={markingComplete}>
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleMarkComplete}
                disabled={markingComplete}
              >
                {markingComplete ? (
                  <><Loader2 className="size-4 animate-spin" /> Submitting…</>
                ) : (
                  <><ShieldCheck className="size-4" /> Yes, Mark Complete</>
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
