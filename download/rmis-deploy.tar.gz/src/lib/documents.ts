// ============================================================================
// documents.ts — Shared helpers for the filesystem-based document store.
//
// The production DB has NO dedicated `documents` table for the
// document-intelligence feature — uploaded files live on disk under
// `upload/<applicantId>/` with a sidecar `.meta.json` per file. This module
// centralizes the meta-sidecar read/list logic so both the applicant-facing
// upload API (`/api/applicant/documents`) and the admin/evaluator-facing
// applicant-details API (`/api/admin/applicants/[id]`) share one implementation.
// ============================================================================

import { uploadDir } from "@/lib/env";
import fs from "fs/promises";
import path from "path";
import type { ValidDocumentCategory } from "@/lib/file-types";

export type DocumentMeta = {
  id: string; // = uuid (no DB primary key)
  applicantId: number;
  uploadedById: number;
  fileName: string;
  originalName: string;
  mimeType: string;
  size: number;
  filePath: string; // relative to project root, e.g. "upload/123/uuid.xlsx"
  category: ValidDocumentCategory;
  status: "UPLOADED" | "PROCESSING" | "EXTRACTED" | "PARTIALLY_EXTRACTED" | "FAILED";
  extractedJson?: string | null;
  extractionError?: string | null;
  extractedAt?: string | null;
  createdAt: string;
  updatedAt: string;
  fileTableId?: number | null;
};

/** Read a single `.meta.json` sidecar. Returns null if missing or unparseable. */
export async function readMeta(metaPath: string): Promise<DocumentMeta | null> {
  try {
    const raw = await fs.readFile(metaPath, "utf-8");
    return JSON.parse(raw) as DocumentMeta;
  } catch {
    return null;
  }
}

/** Write a `.meta.json` sidecar (used by the upload route). */
export async function writeMeta(metaPath: string, meta: DocumentMeta): Promise<void> {
  await fs.writeFile(metaPath, JSON.stringify(meta, null, 2), "utf-8");
}

/**
 * List all uploaded documents for an applicant by reading the sidecar JSON
 * files in `upload/<applicantId>/`. Sorted newest-first by `createdAt`.
 * Returns an empty array if the directory does not exist (no uploads yet).
 */
export async function listApplicantDocuments(
  applicantId: number
): Promise<DocumentMeta[]> {
  const dir = path.join(uploadDir(), String(applicantId));
  let entries: string[] = [];
  try {
    entries = await fs.readdir(dir);
  } catch {
    return [];
  }
  const metaFiles = entries.filter((f) => f.endsWith(".meta.json"));
  const out: DocumentMeta[] = [];
  for (const f of metaFiles) {
    const m = await readMeta(path.join(dir, f));
    if (m) out.push(m);
  }
  out.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  return out;
}
