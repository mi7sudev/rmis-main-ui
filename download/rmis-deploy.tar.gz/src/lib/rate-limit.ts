// Simple in-memory rate limiter for login brute-force protection.
// In production, replace with Redis-based rate limiting (or the API gateway's
// built-in rate limiting). This is a minimum viable protection for the dev/staging
// environment — it resets on server restart.

type RateLimitEntry = {
  count: number;
  resetAt: number;
};

const loginAttempts = new Map<string, RateLimitEntry>();
const MAX_LOGIN_ATTEMPTS = 5;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const LOCKOUT_MS = 30 * 60 * 1000; // 30 minutes lockout after 5 failed attempts

/**
 * Check if the given identifier (IP + username) is rate-limited.
 * Returns { allowed: boolean, retryAfterMs?: number }
 */
export function checkLoginRateLimit(identifier: string): {
  allowed: boolean;
  retryAfterMs?: number;
  remaining?: number;
} {
  const key = identifier.toLowerCase();
  const now = Date.now();
  const entry = loginAttempts.get(key);

  if (!entry) {
    return { allowed: true, remaining: MAX_LOGIN_ATTEMPTS };
  }

  // If the window has passed, reset
  if (now > entry.resetAt) {
    loginAttempts.delete(key);
    return { allowed: true, remaining: MAX_LOGIN_ATTEMPTS };
  }

  // If locked out (count exceeded and still in lockout window)
  if (entry.count >= MAX_LOGIN_ATTEMPTS) {
    const retryAfterMs = entry.resetAt - now;
    return { allowed: false, retryAfterMs };
  }

  return { allowed: true, remaining: MAX_LOGIN_ATTEMPTS - entry.count };
}

/**
 * Record a failed login attempt for the given identifier.
 */
export function recordFailedLogin(identifier: string): void {
  const key = identifier.toLowerCase();
  const now = Date.now();
  const existing = loginAttempts.get(key);

  if (!existing || now > existing.resetAt) {
    // Start a new window with lockout duration if this is the 5th attempt
    const count = existing ? existing.count + 1 : 1;
    loginAttempts.set(key, {
      count,
      resetAt: count >= MAX_LOGIN_ATTEMPTS ? now + LOCKOUT_MS : now + WINDOW_MS,
    });
  } else {
    existing.count += 1;
    if (existing.count >= MAX_LOGIN_ATTEMPTS) {
      // Extend lockout on the 5th attempt
      existing.resetAt = now + LOCKOUT_MS;
    }
  }
}

/**
 * Clear rate limit on successful login.
 */
export function clearLoginRateLimit(identifier: string): void {
  loginAttempts.delete(identifier.toLowerCase());
}

// ---------------------------------------------------------------------------
// Generic per-action limiter (in-memory, resets on restart) — used for
// sensitive free-form actions such as direct emails to applicants.
// ---------------------------------------------------------------------------

const actionAttempts = new Map<string, RateLimitEntry>();

/**
 * Consume one slot from a generic sliding-window quota. Records the attempt
 * and reports whether the caller is still under the limit.
 * Example: direct emails — 20 sends per user per 10 minutes.
 */
export function consumeRateLimit(
  key: string,
  limit: number,
  windowMs: number
): { allowed: boolean; retryAfterMs?: number } {
  const k = key.toLowerCase();
  const now = Date.now();
  const entry = actionAttempts.get(k);

  if (!entry || now > entry.resetAt) {
    actionAttempts.set(k, { count: 1, resetAt: now + windowMs });
    return { allowed: true };
  }
  if (entry.count >= limit) {
    return { allowed: false, retryAfterMs: entry.resetAt - now };
  }
  entry.count += 1;
  return { allowed: true };
}

/**
 * Get client IP from NextRequest, accounting for the Caddy reverse proxy.
 */
export function getClientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }
  const realIp = req.headers.get("x-real-ip");
  if (realIp) {
    return realIp;
  }
  return "unknown";
}
