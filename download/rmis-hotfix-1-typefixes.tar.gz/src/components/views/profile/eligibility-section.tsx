// =============================================================================
// RMIS — Profile View: Eligibility Section (Accenture language)
// Flat sharp cards on the mode-aware canvas — no rounded corners, no shadows.
// ==============================================================================

"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { EmptyState } from "@/components/primitives/workspace";
import { formatDate } from "@/lib/client";
import { toast } from "sonner";
import { ShieldCheck, Plus, Loader2 } from "lucide-react";
import { EligibilityItem, ReferenceData, toISODate, isPendingId } from "./types";
import {
  SectionHeader,
  EntityCard,
  FormField,
} from "./form-fields";

// Sentinel value used in the eligibility title <Select> to indicate that the
// user wants to type a custom title that isn't in the predefined list. When
// this is selected, a separate text input is revealed for the custom value.
const OTHERS_VALUE = "__OTHERS__";

export function EligibilitySection({
  items,
  reference,
  onCreate,
  onUpdate,
  onDelete,
}: {
  items: EligibilityItem[];
  reference: ReferenceData | null;
  onCreate: (payload: Record<string, unknown>) => Promise<EligibilityItem | null>;
  onUpdate: (id: string, payload: Record<string, unknown>) => Promise<boolean>;
  onDelete: (id: string) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<EligibilityItem | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  function openCreate() {
    setEditing(null);
    setForm({
      eligibilityTitle: "",
      eligibilityTitleCustom: "",
      rating: "",
      examDate: "",
      examPlace: "",
      licenseNumber: "",
      licenseValidity: "",
    });
    setOpen(true);
  }

  function openEdit(item: EligibilityItem) {
    setEditing(item);
    // If the item's title matches a predefined reference option, pre-select
    // it in the dropdown. Otherwise, fall back to "Others" and populate the
    // custom title field so the user can edit their custom value.
    const knownNames =
      reference?.eligibilities?.map((e) => e.name) ?? [];
    const isKnown =
      !!item.eligibilityTitle && knownNames.includes(item.eligibilityTitle);
    setForm({
      eligibilityTitle: isKnown ? (item.eligibilityTitle ?? "") : OTHERS_VALUE,
      eligibilityTitleCustom: isKnown ? "" : item.eligibilityTitle ?? "",
      rating: item.rating ?? "",
      examDate: toISODate(item.examDate) ?? "",
      examPlace: item.examPlace ?? "",
      licenseNumber: item.licenseNumber ?? "",
      licenseValidity: toISODate(item.licenseValidity) ?? "",
    });
    setOpen(true);
  }

  async function submit() {
    // Resolve the final title: if the user picked "Others", use the custom
    // text they typed; otherwise use the selected predefined option.
    const finalTitle =
      form.eligibilityTitle === OTHERS_VALUE
        ? form.eligibilityTitleCustom
        : form.eligibilityTitle;
    if (!finalTitle?.trim()) {
      toast.error(
        form.eligibilityTitle === OTHERS_VALUE
          ? "Please type your eligibility title"
          : "Eligibility title is required"
      );
      return;
    }
    setSaving(true);
    const payload: Record<string, unknown> = {
      eligibilityTitle: finalTitle || null,
      rating: form.rating || null,
      examDate: form.examDate || null,
      examPlace: form.examPlace || null,
      licenseNumber: form.licenseNumber || null,
      licenseValidity: form.licenseValidity || null,
    };
    try {
      if (editing) {
        if (isPendingId(editing.id)) {
          await onCreate(payload);
          await onDelete(editing.id);
        } else {
          await onUpdate(editing.id, payload);
        }
      } else {
        await onCreate(payload);
      }
      setOpen(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Eligibility"
        description="Government and professional examinations passed"
        icon={ShieldCheck}
        action={
          <Button onClick={openCreate} variant="outline">
            <Plus className="h-4 w-4" /> Add Eligibility
          </Button>
        }
      />

      <section className="rounded-none border border-border bg-card">
      {items.length === 0 ? (
        <div className="p-4 sm:p-6">
        <EmptyState
          title="No eligibility entries yet"
          description="Add civil service or professional eligibilities you've earned, or upload eligibility certificates to auto-extract."
          icon={<ShieldCheck className="h-7 w-7" />}
          action={
            <Button onClick={openCreate} variant="outline">
              <Plus className="h-4 w-4" /> Add Eligibility
            </Button>
          }
        />
        </div>
      ) : (
        <div className="sm:max-h-[480px] sm:overflow-y-auto sm:pr-1">
          <div className="space-y-3 p-4">
            {items.map((item) => (
              <EntityCard
                key={item.id}
                fromExtraction={item.__fromExtraction}
                onEdit={() => openEdit(item)}
                onDelete={() => onDelete(item.id)}
                rows={[
                  { label: "Title", value: item.eligibilityTitle },
                  { label: "Rating", value: item.rating },
                  {
                    label: "Exam Date",
                    value: item.examDate ? formatDate(item.examDate) : null,
                  },
                  { label: "Exam Place", value: item.examPlace },
                  { label: "License No.", value: item.licenseNumber },
                  {
                    label: "License Validity",
                    value: item.licenseValidity
                      ? formatDate(item.licenseValidity)
                      : null,
                  },
                ]}
              />
            ))}
          </div>
        </div>
      )}
      </section>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[520px]">
          <DialogHeader className="shrink-0">
            <DialogTitle className="font-bold tracking-[-0.01em] text-foreground">
              {editing ? "Edit Eligibility Entry" : "Add Eligibility Entry"}
            </DialogTitle>
            <DialogDescription>
              Enter your eligibility / examination details.
            </DialogDescription>
          </DialogHeader>
          <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 overflow-y-auto py-2 pr-1 md:grid-cols-2">
            <div className="md:col-span-2">
              <Label className="font-semibold text-foreground">
                Eligibility Title <span className="text-danger-ink">*</span>
              </Label>
              {reference?.eligibilities?.length ? (
                <>
                  <Select
                    value={form.eligibilityTitle}
                    onValueChange={(v) =>
                      setForm((p) => ({ ...p, eligibilityTitle: v }))
                    }
                  >
                    <SelectTrigger className="mt-1.5 h-11 w-full">
                      <SelectValue placeholder="Select an eligibility" />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      {reference.eligibilities.map((e) => (
                        <SelectItem key={e.id} value={e.name}>
                          {e.name}
                        </SelectItem>
                      ))}
                      <SelectItem value={OTHERS_VALUE}>
                        Others (type manually)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  {form.eligibilityTitle === OTHERS_VALUE && (
                    <Input
                      value={form.eligibilityTitleCustom}
                      onChange={(e) =>
                        setForm((p) => ({
                          ...p,
                          eligibilityTitleCustom: e.target.value,
                        }))
                      }
                      className="mt-2"
                      placeholder="Type your eligibility title"
                      autoFocus
                    />
                  )}
                </>
              ) : (
                <Input
                  value={form.eligibilityTitle}
                  onChange={(e) =>
                    setForm((p) => ({ ...p, eligibilityTitle: e.target.value }))
                  }
                  className="mt-1.5"
                  placeholder="e.g. Civil Service Professional"
                />
              )}
            </div>
            <FormField
              label="Rating"
              value={form.rating}
              onChange={(v) => setForm((p) => ({ ...p, rating: v }))}
              placeholder="e.g. 85.50%"
            />
            <FormField
              label="Exam Date"
              value={form.examDate}
              onChange={(v) => setForm((p) => ({ ...p, examDate: v }))}
              type="date"
            />
            <FormField
              label="Exam Place"
              value={form.examPlace}
              onChange={(v) => setForm((p) => ({ ...p, examPlace: v }))}
            />
            <FormField
              label="License Number"
              value={form.licenseNumber}
              onChange={(v) => setForm((p) => ({ ...p, licenseNumber: v }))}
            />
            <FormField
              label="License Validity"
              value={form.licenseValidity}
              onChange={(v) => setForm((p) => ({ ...p, licenseValidity: v }))}
              type="date"
            />
          </div>
          <DialogFooter className="shrink-0">
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button
              onClick={submit}
              disabled={saving}
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin mr-1.5" />}
              {editing ? "Save Changes" : "Add Entry"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
